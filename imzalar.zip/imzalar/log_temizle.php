<? ob_start();
include("guiconfig.inc");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log Temizle</title>
<? include("head.inc");?>
</head>
<? include("fbegin.inc");?>
<body>

<p class="pgtitle">Log Silme:</p>
<?

$file=$_GET['dosya'];
$type=$_GET['t'];

if (!eregi("(^[a-zA-Z0-9]+([a-zA-Z\_0-9\.-]*))$",$file)){
	$hata.="Dosya Adında Geçersiz Karakterler Tespit Edildi!<br />Silme işlemi yapılmayacak!";
}

if ($file==""){
	$hata.="Dosya Adı Boş Olamaz!<br />";
}
$bugun=time();
if($hata==""){
	switch ($type){
		case 1:
			#5651ftp.log.200911190042.tar.gz
			$hrn=explode('.',$file);
		
			$tarih=substr($hrn[2],0,8);
			
			$dizin=str_replace('5651','',$hrn[0]);
			$yol="/usr/local/www/imzalar/imzali_kayitlar/$dizin/5651$dizin$tarih/$file";
			
			$fdate=strtotime($tarih);
			$datediff=floor(($bugun - $fdate)/(60*60*24));

			if ($datediff>=190){
				print "<h3>" .$file ." Dosyası Silindi!</h3>";	
				unlink($yol);
			}else{
				print "<h3> Silmek İstediğiniz Dosya 6 Aydan Daha Yeni!<br />Bu Dosyayı Silemezsiniz!<br/>";	
			}
			
		break;
		
		case 2:
			$hrn=explode('.',$file);		
			$tarih=substr($hrn[2],0,8);			
			$dizin=str_replace('5651','',$hrn[0]);			
			$yol="/usr/local/www/imzalar/nitelikli_imzali_kayitlar/5651-$tarih/$file";			
			$fdate=strtotime($tarih);
			$datediff=floor(($bugun - $fdate)/(60*60*24));

			if ($datediff>=190){
				print "<h3>" .$file ." Dosyası Silindi!</h3>";	
				unlink($yol);
			}else{
				print "<h3> Silmek İstediğiniz Dosya 6 Aydan Daha Yeni!<br />Bu Dosyayı Silemezsiniz!<br/>";	
			}
			break;

		default:
		   echo "Geçersiz istek";
	}
	

//	if ($type=2){
//		#5651ftp.log.200911190042.tar.gz
//		print $file;
//		$tarih=substr($hrn[2],0,8);
//		$dizin=str_replace('5651','',$hrn[0]);
//	
//		$yol="/usr/local/www/imzalar/imzali_kayitlar/$dizin/5651$dizin$tarih/$file";
//		print $yol;
//		print "<h3>" .$file ." Dosyası Silindi!</h3>";	
	//	unlink($yol);
//	}
	
	
}else{
	print $hata;
}

?>
<br /><input type="button" name="geri" value="Geri Dön" class="formbtn" onClick="history.back()" />
<? include("fend.inc");?>
</body>
</html>