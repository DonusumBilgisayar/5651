<?php 
ob_start();
/* $Id$ */
/*

	cron_edit.php
	Copyright (C) 2008 Mark J Crane
	All rights reserved.
	
	Redistribution and use in source and binary forms, with or without
	modification, are permitted provided that the following conditions are met:
	
	1. Redistributions of source code must retain the above copyright notice,
	   this list of conditions and the following disclaimer.
	
	2. Redistributions in binary form must reproduce the above copyright
	   notice, this list of conditions and the following disclaimer in the
	   documentation and/or other materials provided with the distribution.
	
	THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,
	INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
	AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
	AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
	OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
	SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
	INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
	CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
	ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
	POSSIBILITY OF SUCH DAMAGE.
*/
require("guiconfig.inc");
$pgtitle = "Log > imzalama Periyodu";

$pconfig['reverse'] = isset($config['syslog']['reverse']);
$pconfig['nentries'] = $config['syslog']['nentries'];
$pconfig['remoteserver'] = $config['syslog']['remoteserver'];
$pconfig['filter'] = isset($config['syslog']['filter']);
$pconfig['dhcp'] = isset($config['syslog']['dhcp']);
$pconfig['portalauth'] = isset($config['syslog']['portalauth']);
$pconfig['vpn'] = isset($config['syslog']['vpn']);
$pconfig['system'] = isset($config['syslog']['system']);
$pconfig['enable'] = isset($config['syslog']['enable']);
$pconfig['logdefaultblock'] = !isset($config['syslog']['nologdefaultblock']);
$pconfig['rawfilter'] = isset($config['syslog']['rawfilter']);
$pconfig['disablelocallogging'] = isset($config['syslog']['disablelocallogging']);

if (!$pconfig['nentries'])
	$pconfig['nentries'] = 50;
	
require("/usr/local/pkg/cron.inc");
$a_cron 	   = &$config['cron']['item'];

function getCronId($cmd) {
  global $config;

  if (is_array($config['cron']['item'])) {
    for ($i = 0; $i < count($config['cron']['item']); $i++) {
      $item =& $config['cron']['item'][$i];

      if (strpos($item['command'], $cmd) !== false) {
        return array("ID" => $i, "ITEM" => $item);
      }
    }
  }

  return NULL;
}

$cmd="/usr/local/bin/bash /usr/local/ssl-1/imzaci/imzaci.sh";
$getcron=getCronId($cmd);
$id=$getcron['ID'];


if ($_GET['act'] == "del") {
  if ($_GET['type'] == 'php') {
      if ($a_cron[$id]) {
          unset($a_cron[$id]);
          write_config();
          php_sync_package();
          header("Location: imza_periyodu.php");
          exit;
      }
  }
}

if (isset($id) && $a_cron[$id]) {
	$pconfig['minute'] = $a_cron[$id]['minute'];
	$pconfig['hour'] = $a_cron[$id]['hour'];
	$pconfig['mday'] = $a_cron[$id]['mday'];
	$pconfig['month'] = $a_cron[$id]['month'];
	$pconfig['wday'] = $a_cron[$id]['wday'];
	$pconfig['who'] = $a_cron[$id]['who'];
	$pconfig['command'] = $a_cron[$id]['command'];
	
}

if ($_POST["islem"]=="zamanla") {
	unset($input_errors);
	$pconfig = $_POST;
  
	if (!$input_errors) {

		$ent = array();
		$ent['minute'] = $_POST['minute'];
		$ent['hour'] = $_POST['hour'];
		$ent['mday'] = $_POST['mday'];
		$ent['month'] = $_POST['month'];
		$ent['wday'] = $_POST['wday'];
		$ent['who'] = $_POST['who'];
		$ent['command'] = $_POST['command'];

		if (isset($id) && $a_cron[$id]) {
		  	//update
      		$a_cron[$id] = $ent;
		}
		else {
		  	//add	  
			$a_cron[] = $ent;
		}
		
		write_config();
//		php_sync_package();
		
		//header("Location: ftp2.php?id=12");
		header("Location: imza_periyodu.php");
		exit;
	}
}

include("head.inc");
include("fbegin.inc");
?>
<?
function gu($g,$k){
	if($g==$k){
		$r=' selected="selected"';
	}else{
		$r='';
	}
	return $r;
}

function tarihbicimle($data){
	$yil=substr($data,0,4);
	$ay=substr($data,4,2);
	$gun=substr($data,6,2);
	$saat=substr($data,8,2);
	$dk=substr($data,10,2);
	$ret = $gun."/".$ay."/". $yil ." - ". $saat . ":" . $dk;
	return $ret;
}

?>


    <?
	if($id==$id){
	?>
    <?php if ($input_errors) print_input_errors($input_errors); 
	/*$tab_array = array();
	$tab_array[] = array("Yerel imza Periyodu", true, "imza_periyodu.php");
	$tab_array[] = array("Nitelikli imza Periyodu", false, "nitelikli_imza_periyodu.php");
	display_top_tabs($tab_array);*/
	$tab_array = array();
	$tab_array[] = array("Yerel imza Periyodu", true, "imza_periyodu.php");
	$tab_array[] = array("Nitelikli imza Periyodu", false, "imza_periyodu.php");
	$tab_array[] = array("Log Yoneticisi", false, "imza_periyodu.php");
	display_top_tabs($tab_array);

	?><br />

        <form action="imza_periyodu.php" method="post" name="iform" id="iform">
          <input name="islem" type="hidden" id="islem" value="zamanla" />
            <table width="562" border="0" align="left" cellpadding="6" cellspacing="0">		
            <input name="minute" type="hidden" value="0" />
            <input name="wday" type="hidden" value="*" />
            <input type="hidden" name="who" size="40" value="root">
            <input name="command" type="hidden" class="formfld" id="command" size="40" value="<?=$cmd?>">
            <input name="month" type="hidden" class="formfld" id="month" size="40" value="*">
            <input name="mday" type="hidden" class="formfld" id="mday" size="40" value="*">
            <input name="id" type="hidden" value="<?=$id;?>">
            <tr>
              <td width="7%" valign="middle"class="vtable" >Her</td>
              <td width="11%" valign="middle" class="vtable">
              <select name="hour" id="hour">
                    <option value="*/24" <?=gu($pconfig['hour'],'*/24');?>>24</option>
                    <option value="*/1" <?=gu($pconfig['hour'],'*/1');?>>1</option>
                    <option value="*/2" <?=gu($pconfig['hour'],'*/2');?>>2</option>
                    <option value="*/3" <?=gu($pconfig['hour'],'*/3');?>>3</option>
                    <option value="*/4" <?=gu($pconfig['hour'],'*/4');?>>4</option>
                    <option value="*/5" <?=gu($pconfig['hour'],'*/5');?>>5</option>
                    <option value="*/6" <?=gu($pconfig['hour'],'*/6');?>>6</option>
                    <option value="*/7" <?=gu($pconfig['hour'],'*/7');?>>7</option>
                    <option value="*/8" <?=gu($pconfig['hour'],'*/8');?>>8</option>                    
                    <option value="*/9" <?=gu($pconfig['hour'],'*/9');?>>9</option>
                    <option value="*/10" <?=gu($pconfig['hour'],'*/10');?>>10</option>
                    <option value="*/11" <?=gu($pconfig['hour'],'*/11');?>>11</option>
                    <option value="*/12" <?=gu($pconfig['hour'],'*/12');?>>12</option>
                    <option value="*/13" <?=gu($pconfig['hour'],'*/13');?>>13</option>
                    <option value="*/14" <?=gu($pconfig['hour'],'*/14');?>>14</option>
                    <option value="*/15" <?=gu($pconfig['hour'],'*/15');?>>15</option>
                    <option value="*/16" <?=gu($pconfig['hour'],'*/16');?>>16</option>
                    <option value="*/17" <?=gu($pconfig['hour'],'*/17');?>>17</option>                    
                    <option value="*/18" <?=gu($pconfig['hour'],'*/18');?>>18</option>
                    <option value="*/19" <?=gu($pconfig['hour'],'*/19');?>>19</option>
                    <option value="*/20" <?=gu($pconfig['hour'],'*/20');?>>20</option>
                    <option value="*/21" <?=gu($pconfig['hour'],'*/21');?>>21</option>
                    <option value="*/22" <?=gu($pconfig['hour'],'*/22');?>>22</option>
                    <option value="*/23" <?=gu($pconfig['hour'],'*/23');?>>23</option>
             </select></td>
              <td width="48%" valign="middle" class="vtable" >saat de bir imzalama islemi yapilsin..</td>
              <td width="34%" valign="middle" class="vtable" ><input name="Submit" type="submit" class="formbtn" value="Kaydet" /></td>
            </tr>
            <tr>
              <td valign="top">&nbsp;</td>
              <td colspan="3"><?php if (isset($id) && $a_cron[$id]): ?>

                <?php endif; ?>
              </td>
            </tr>
            </table>
</form>
 <form action="imza_periyodu.php" method="post" name="iform" id="iform">
<table width="200" border="0" align="left" cellpadding="6" cellspacing="0">
  <tr>
    <td>&nbsp;<input name="islem" type="hidden" id="islem" value="imzala" /><input name="imzala" type="submit" value="simdi imzala" class="formbtn" /></td>
    </tr>
  <tr>
    <td>&nbsp;</td>
    </tr>
</table>
 </form>
  

<? if ($_POST["islem"]=="imzala") {
	exec($cmd,$ret);
}?>
<p></p>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<p class="pgtitle">imzalama islemleri</p>

<textarea cols="60" rows="20" style="border:1px;width:750px;"><?php 
	 if ($data=@file_get_contents('/usr/local/ssl-1/imzaci/imzaci.log')){
		$line=explode("\n",$data);
		$limit=count($line);
		$s=0;
		for ($i=$limit;$i>=0;$i--){
			$x=tarihbicimle($line[$i]);
			if ($x!="// - :"){
				echo "   " .$x . " tarihinde islem yapildi\n";
			}
			$s++;
		}
	}
?></textarea>
	<?
		}else{
			include_once('packages/cron/cron.php');
		}
		?>
<?php include("fend.inc"); ?>
