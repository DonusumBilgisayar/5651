<? ob_start();
include("guiconfig.inc");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>İmza Doğrulama </title>
<? include("head.inc");?>
</head>

<body>
<? include("fbegin.inc");?>
<?
$dosya=$_GET["dosya"];
$type=$_GET["t"];

switch($type){
	case 1:
		$x=explode("/", $dosya);
		$y=explode(".",$x[3]);
		$ad=$y[0] .".". $y[1];
		$testcmd="/usr/local/ssl-1/bin/openssl ts -verify -data /tmp/.log/$ad -in /tmp/.log/$ad.der -token_in -CAfile /CA/cacert.pem -untrusted /CA/tsacert.pem";
		break;
	
	case 2:
		#nitelikli_imzali_kayitlar/5651-20100106/TRtrust.NI.201001061556.tar.gz
		$x=explode("/",$dosya);
		$ad=str_replace(".tar.gz","",$x[count($x)-1]);
		$ad=str_replace("TRtrust.","",$ad);
		#print $ad;
		$testcmd="/usr/local/ssl-1/bin/openssl ts -verify -data /tmp/.log/$ad.tar.gz -in /tmp/.log/$ad.tsr -CAfile /usr/local/ssl-1/imzaci/TRtrust.pem";
		#print $testcmd;
	break;
}

$temizlecmd="mkdir -p /tmp/.log && /bin/rm -rf /tmp/.log/*";
$tarcmd="/usr/bin/tar zxvf /usr/local/www/imzalar/$dosya -C /tmp/.log/";
system($temizlecmd);
system($tarcmd);
exec($testcmd,$sonuc);
$sonuc=str_replace("Verification","İmza Doğrulama",$sonuc[0]);
$sonuc=str_replace("FAILED","İmza Geçersiz. Dosya Değiştirilmiş.",$sonuc);
$sonuc=str_replace("OK","İmza Geçerli. Dosya Değiştirilmemiş.",$sonuc);

?><p class="pgtitle">İmza Doğrulama:</p>
 <p class="vexpl">DOSYA: <?=$dosya?></p> 

 <p class="vexpl"><?=$sonuc?></p>
<br /><input type="button" name="geri" value="Geri Dön" class="formbtn" onClick="history.back()" />
<? include("fend.inc");?>
</body>
</html>